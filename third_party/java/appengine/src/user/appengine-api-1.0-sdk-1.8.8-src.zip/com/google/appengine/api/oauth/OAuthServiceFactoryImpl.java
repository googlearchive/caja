// Copyright 2012 Google Inc. All rights reserved.

package com.google.appengine.api.oauth;

/**
 * Creates an OAuthService.
 *
 */
final class OAuthServiceFactoryImpl implements IOAuthServiceFactory {
  @Override
  public OAuthService getOAuthService() {
    return new OAuthServiceImpl();
  }

}
