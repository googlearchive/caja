// Copyright 2010 Google Inc. All rights reserved.
package com.google.appengine.api.taskqueue;

/**
 * Intermittent failure.
 * <p>The requested operation may succeed if attempted again.
 *
 */
public class TransientFailureException extends RuntimeException {
  private static final long serialVersionUID = -1118669314524539086L;

  public TransientFailureException(String detail) {
    super(detail);
  }
}
